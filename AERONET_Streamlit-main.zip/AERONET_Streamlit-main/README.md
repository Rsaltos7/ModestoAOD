# AERONET Data Viewer Using Streamlit
Brief examples of how to get streamlit going.

Step 1: Fork this repository (or make your own)

Step 2: Make an account on [https://share.streamlit.io](https://streamlit.io/) and connect it to your GitHub account

Step 3: Deploy an app based on the forked repository (using the streamlit.io web interface)

Step 4: Customize your main.py code to fit your needs; your streamlit page will update automatically.
